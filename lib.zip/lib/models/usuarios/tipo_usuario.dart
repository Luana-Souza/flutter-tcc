enum TipoUsuario{
  professor, aluno
}